/*
 * @author Jordan Kramer
 * CS 340 
 * John Matta
 * Interface
 */
package cs340.sortable;

public interface Sortable {
    
    public void sort(String array[]);

}
